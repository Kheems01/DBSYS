﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppCrud.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var list = new List<user>();
            using (var db = new dbsys32Entities1())
            {
                list = db.user.ToList();
            }
            

                return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(user a)
        {
            using (var db = new dbsys32Entities1())
            {
                var newUser = new user();
                newUser.username = a.username;
                newUser.password = a.password;

                db.user.Add(newUser);
                db.SaveChanges();

                TempData["msg"] = $"Added {newUser.username} Successfully!";
            }
            return RedirectToAction("Index");

        }
        public ActionResult Update(int id)
        {
            var a = new user();
            using (var db = new dbsys32Entities1())
            {
                a = db.user.Find(id);
            }

            return View(a);
        }
        [HttpPost]
        public ActionResult Update(user a)
        {
            using (var db = new dbsys32Entities1())
            {
                var newUser = db.user.Find(a.id);
                newUser.username = a.username;
                newUser.password = a.password;


                db.SaveChanges();

                TempData["msg"] = $"Updated {newUser.username} Successfully!";
            }
            return RedirectToAction("Index");

        }
        public ActionResult Delete(int id)
        {
            var a = new user();
            using (var db = new dbsys32Entities1())
            {
                a = db.user.Find(id);
                db.user.Remove(a);
                db.SaveChanges();

                TempData["msg"] = $"Deleted {a.username} Successfully!";

            }

            return RedirectToAction("Index");
        }
    }
}